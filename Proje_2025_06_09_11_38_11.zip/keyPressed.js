class keyPressedCls{
  
  keyPressedFun(){
    
    
    // Dart ekranından çıkış için "b"
  if ((currentEkran == "dartPage" || currentScren == "dartEkranı") && key === "b" && currentEkran != "savasOyunEkranı") {
    currentEkran = "anaSayfa";
    currentScren = "window";
    i = 0;

    // Bilgisayar kontrolü açıksa mouse kontrol açılır
    if (bilgisayarKontrol) {
      mouseKontrol = true;
    }
  }

  // ESC ile oyunu durdur / devam ettir
  if (currentEkran == "savasOyunEkranı" && keyCode === 27) {
    currentEkran = "araSayfa";
    escKontrol = !escKontrol;
  } else if (currentEkran == "araSayfa" && keyCode === 27) {
    currentEkran = "savasOyunEkranı";
    escKontrol = !escKontrol;
  }

  // Boşluk ile füze ateşi
  if (key === " " && currentEkran == "savasOyunEkranı") {
    for (let i = 0; i < (seviye >= 3 ? 2 : 1); i++) {
      füzeX.push(aracX + i * 30); // Farklı pozisyondan iki füze
      füzeY.push(aracY);
    }
  }

  // Sağ ve sol yön tuşları ile hareket
  if (key === "d") {
    aracX += 7;
  }
  if (key === "a") {
    aracX -= 7;
  }
  }
  
  
}