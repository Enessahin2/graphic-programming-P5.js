class mousePressedCls {
  mousePressedFonk() {
    
    // 🎵 Durdur bölgesi - beyaz nokta ile müzik durdur/play
    if (
      noktaX > 310 && noktaX < 370 &&
      noktaY > 370 && noktaY < 389 &&
      currentSong?.isPlaying
    ) {
      for (let i = 0; i < sesler.length; i++) {
        if (sesler[i].isPlaying()) {
          sesler[i].stop(); // Şarkı çalıyorsa durdur
        }
        if (!button) {
          currentSong.play(); // Şarkı çalmıyorsa başlat
        }
      }
    }

    // 💡 Lamba kontrol (masaüstünde, oyun ekranında değilken)
    if (mouseX > 660 && mouseX < 740 && mouseY > 260 && mouseY < 340 &&
        currentEkran != "savasOyunEkranı" && currentEkran != "araSayfa" &&
        currentEkran != "myHpEkranı" && currentEkran != "girisSayfa") {
      lambaKontrol = !lambaKontrol;
    }

    // 💻 Bilgisayar aç/kapa (masaüstü ekranında)
    if (mouseX > 104 && mouseX < 134 && mouseY > 346 && mouseY < 376 &&
        currentEkran == "anaSayfa") {
      bilgisayarKontrol = !bilgisayarKontrol;
      mouseKontrol = !mouseKontrol;
      currentScren = "window";
      currentEkran = "anaSayfa";
    }

    // 📁 Masaüstü klasöre tıklama (klasör ekranına geçiş)
    if (currentScren == "window" && currentEkran == "anaSayfa") {
      if (
        noktaX > 231 && noktaX < 296 &&
        noktaY > 236 && noktaY < 296 &&
        mouseX > 550 && mouseX < 770 &&
        mouseY > 530 && mouseY < 700
      ) {
        currentScren = "klasorEkranı";
        masaUstu.imgOlusturma();
      }
    }

    // 📁 Klasör ekranından geri dönüş
    else if (currentScren == "klasorEkranı") {
      if (
        noktaX > 231 && noktaX < 296 &&
        noktaY > 236 && noktaY < 296 &&
        mouseX > 550 && mouseX < 770 &&
        mouseY > 530 && mouseY < 700
      ) {
        currentScren = "window";
        masaUstu.imgOlusturma();
        ekranSecme();
      }

      // 🎵 Şarkı seçimleri
if (noktaX > 300 && noktaX < 366 && noktaY > 236 && noktaY < 296 && bilgisayarKontrol) {
  if (currentSong?.isPlaying()) { currentSong.stop(); }
  currentSong = sesler[0];
  currentSong.play();
} else if (noktaX > 380 && noktaX < 440 && noktaY > 236 && noktaY < 296 && bilgisayarKontrol) {
  if (currentSong?.isPlaying()) { currentSong.stop(); }
  currentSong = sesler[1];
  currentSong.play();
} else if (noktaX > 380 && noktaX < 440 && noktaY > 316 && noktaY < 376 && bilgisayarKontrol) {
  if (currentSong?.isPlaying()) { currentSong.stop(); }
  currentSong = sesler[2];
  currentSong.play();
} else if (noktaX > 300 && noktaX < 366 && noktaY > 300 && noktaY < 360 && bilgisayarKontrol) {
  if (currentSong?.isPlaying()) { currentSong.stop(); }
  currentSong = sesler[3];
  currentSong.play();
} else if (noktaX > 233 && noktaX < 332 && noktaY > 300 && noktaY < 360 && bilgisayarKontrol && !sutunBool) {
  if (currentSong?.isPlaying()) { currentSong.stop(); }
  currentSong = sesler[4];
  currentSong.play();
}
}

    // 🪟 Windows düğmesine basınca sütun aç/kapa
    if (noktaX > 230 && noktaX < 250 && noktaY > 390 && noktaY < 410 && bilgisayarKontrol) {
      sutunBool = !sutunBool;
    }

    // 📁 Sütun klasöre tıklanınca klasöre git
    if (noktaX > 230 && noktaX < 250 && noktaY > 335 && noktaY < 355 && bilgisayarKontrol && sutunBool) {
      currentScren = "klasorEkranı";
      sutunBool = false;
    }

    // 🕹️ Savaş oyununa geç
    if (noktaX > 230 && noktaX < 250 && noktaY > 360 && noktaY < 375 && bilgisayarKontrol && sutunBool) {
      currentEkran = "savasOyunEkranı";
      currentScren = null;
      sutunBool = false;
    }

    // ❌ Bilgisayar kapatma
    if (noktaX > 258 && noktaX < 278 && noktaY > 390 && noktaY < 410 && bilgisayarKontrol && sutunBool) {
      bilgisayarKontrol = !bilgisayarKontrol;
      mouseKontrol = !mouseKontrol;
      sutunBool = false;
    }

    // 🖱️ Sütun dışına tıklanırsa sütun kapanır
    if ((noktaX > 287 && noktaX < 500 && noktaY > 100 && noktaY < 500 && bilgisayarKontrol) ||
        (noktaX > 230 && noktaX < 285 && noktaY > 100 && noktaY < 337 && bilgisayarKontrol && sutunBool)) {
      sutunBool = false;
    }

    // 🎯 Dart oyununa başla
    if (mouseX > 700 && mouseX < 780 && mouseY > 435 && mouseY < 473 && currentEkran == "anaSayfa") {
      mouseKontrol = false;
      currentScren = "dartEkranı";
      currentEkran = "dartPage";
    }

    // 🎯 Dart nişan halkasını aktif et
    if (currentScren == "dartEkranı" && mouseX > 155 && mouseX < 330 && mouseY > 300 && mouseY < 480) {
      halkaKontrol = true;
      dartFırlatıldımı = false;
    }

    // 🔑 Giriş ekranına gitme (masaüstü üzerinden)
    if (currentScren == "window" && currentEkran == "anaSayfa" && currentScren != "klasorEkranı") {
      if (
        noktaX > 302 && noktaX < 342 &&
        noktaY > 236 && noktaY < 280 &&
        mouseX > 550 && mouseX < 770 &&
        mouseY > 530 && mouseY < 700
      ) {
        currentEkran = "girisSayfa";
        currentScren = null;
        mouseKontrol = false;
        if (sesKontrol && !sesler[5].isPlaying()) {
          sesler[5].loop();
        }
      }
    }

    // 🚀 Füze ateşi (savaş ekranındaysa)
    if (currentEkran == "savasOyunEkranı") {
      x = aracX;
      y = aracY;
      füzeX.push(x);
      füzeY.push(y);
      sesler[6].setVolume(0.2);
      sesler[6].play();
    }

    // ⏸ Ara ekrandaki butonlar
    if (currentEkran == "araSayfa") {
      if (mouseX > width / 2 - 70 && mouseX < width / 2 + 10 &&
          mouseY > height / 2 + 20 && mouseY < height / 2 + 120) {
        currentEkran = "savasOyunEkranı";
      } else if (mouseX > width / 2 + 40 && mouseX < width / 2 + 120 &&
                 mouseY > height / 2 + 20 && mouseY < height / 2 + 120) {
        savasOyunItem.oyunuSifirla();
        currentEkran = "anaSayfa";
        currentScren = "window";
        mouseKontrol = true;
        if (sesler[5].isPlaying()) sesler[5].stop();
      } else if (mouseX > width / 2 + 4 && mouseX < width / 2 + 70 &&
                 mouseY > height / 2 + 150 && mouseY < height / 2 + 257) {
        savasOyunItem.oyunuSifirla();
      }
    }

    // 💔 Can bitti ekranı kontrolleri
    if (currentEkran == "myHpEkranı") {
      if (mouseX > width / 2 - 70 && mouseX < width / 2 + 10 &&
          mouseY > height / 2 + 20 && mouseY < height / 2 + 120) {
        savasOyunItem.oyunuSifirla();
      } else if (mouseX > width / 2 + 40 && mouseX < width / 2 + 120 &&
                 mouseY > height / 2 + 20 && mouseY < height / 2 + 120) {
        savasOyunItem.oyunuSifirla();
        currentEkran = "anaSayfa";
        currentScren = "window";
        mouseKontrol = true;
        if (sesler[5].isPlaying()) sesler[5].stop();
      }
    }

    // 🔓 Savaş Oyunu giriş ekranındaki butonlar
    if (currentEkran == "girisSayfa") {
      if (mouseX > width / 2 - 70 && mouseX < width / 2 + 10 &&
          mouseY > height / 2 + 20 && mouseY < height / 2 + 120) {
        currentEkran = "savasOyunEkranı";
      } else if (mouseX > width / 2 + 40 && mouseX < width / 2 + 120 &&
                 mouseY > height / 2 + 20 && mouseY < height / 2 + 120) {
        savasOyunItem.oyunuSifirla();
        currentEkran = "anaSayfa";
        currentScren = "window";
        mouseKontrol = true;
        if (sesler[5].isPlaying()) sesler[5].stop();
      }
    }

    // 🔊 Ses aç/kapa (3 ekranda ortak)
    if ((["girisSayfa", "myHpEkranı", "araSayfa"].includes(currentEkran)) &&
        mouseX > 666 && mouseX < 766 && mouseY > 10 && mouseY < 120) {
      sesKontrol = !sesKontrol;
      if (!sesKontrol && sesler[5].isPlaying()) {
        sesler[5].stop();
      } else if (sesKontrol && !sesler[5].isPlaying()) {
        sesler[5].loop();
      }
    }
  }
}
