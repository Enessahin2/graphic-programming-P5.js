//arka plan için değişkenler
let arkaPlanFoto=[];
let kartal=[];
let arkaPlanX=0;
let arkaPlanY=0;
let arkaPlanSes;


// Kartal animasyonu için değişkenler
let AnlıkKartalKare = 0;  // Şu anda gösterilen kartal karesinin indeksi
let kartalKanarHızı = 5; // Kartalın kanat çırpma hızı 
let KartalKareDegisim = 0;  // Kartalın kare değişimini sayan sayaç
let kartalX = 0;             // Kartalın X konumu 
let kartalY = 150;           // Kartalın Y konumu 
let kartalUcmaHızı = 2;   // Kartalın ekran boyunca ilerleme hızı
let kartalsound;

//at için tanımlamalar
let at=[];
let AnlıkAtKare = 0;    // Şu anda gösterilen at karesinin indeksi
let atKanarHızı = 5;    // Atın koşma animasyon hızı (daha yüksek değer = daha yavaş koşma)
let AtKareDegisim = 0;  // Atın kare değişimini sayan sayaç
let atX = 0;            // Atın X konumu
let atY = 0;            // Atın Y konumu
let atKosmaHızı = -10;  
let atsound;
let atNesneleri = [];

//kuş tanımlamaları
let kus=[];
let kusNesneleri = []; // Yeni: Birden fazla kuş nesnesini tutacak dizi

//sayaç için değişkenler
let saniyeSayaci = 0;
let baslangicSaniyesi = 0; // millis() cinsinden başlangıç zamanı

// Duraklatma/Devam Ettirme için değişkenler
let oyunDurdu = false;
let pauseStartTime = 0; // Duraklama başlangıç zamanı (milisaniye cinsinden)
 
//aslan için
let aslan=[];
let aslanSound;
let aslanNesneleri = []; // Aslan nesnelerini tutacak dizi 

// Boşluk tuşuna basıldığında durma
function keyPressed() {
if (keyCode === 32) { 
durdurmaItem.durdurmaFnk();
}
}

// Fareye tıklandığında
function mousePressed() {
if (arkaPlanSes && !arkaPlanSes.isPlaying() && !oyunDurdu) {
arkaPlanSes.loop();
}

// Sol tıklama ile duraklatma/devam ettirme
if (mouseButton === LEFT) {
durdurmaItem.durdurmaFnk();
}
}

function preload(){
  //back ground için
  arkaPlanFoto[0]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/new.jpg"); 
  arkaPlanFoto[1]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/newters.jpg");
  
  //adım adım kartal
  kartal[0]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/kartal1-Photoroom.png");
  kartal[1]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/kartal2-Photoroom.png");
  kartal[2]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/kartal3-Photoroom.png");
  kartal[3]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/kartal4-Photoroom.png");
  kartal[4]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/kartal5-Photoroom.png");
  kartal[5]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/kartal6-Photoroom.png");
  kartal[6]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/kartal7-Photoroom.png");
  kartal[7]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/kartal8-Photoroom.png");
  kartal[8]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/kartal9-Photoroom.png");
  
  //adım adım at
  at[0]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/at1.png");
  at[1]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/at2.png");
  at[2]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/at3.png");
  at[3]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/at4.png");
  at[4]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/at5.png");
  at[5]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/at6.png");
  at[6]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/at7.png");
  at[7]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/at8.png");
  at[8]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/at9.png");
  at[9]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/at10.png");
  at[10]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/at11.png");
  at[11]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/at12.png");

  //adım adım kuş
  kus[0]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/ku%C5%9F1-Photoroom.png");
  kus[1]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/ku%C5%9F2-Photoroom.png");
  kus[2]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/ku%C5%9F3-Photoroom.png");
  kus[3]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/ku%C5%9F4-Photoroom.png");

//kartal sesi
kartalsound=loadSound("https://file.garden/aCTjXiikymDr1qHZ/%C5%9Eahin%20sesi%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20(V%C4%B0DEO%20SESLER%C4%B0%20).mp3")
//arka plan ses
arkaPlanSes=loadSound("https://file.garden/aCTjXiikymDr1qHZ/depositphotos_425176694-track-jungle-ambience-sound-effect-VEED.mp3")
//at sesi
atsound=loadSound("https://file.garden/aCTjXiikymDr1qHZ/%F0%9F%90%8E%20K%C4%B0%C5%9ENEMES%C4%B0%20%F0%9F%90%8E%F0%9F%98%8C%F0%9F%A7%BF.mp3")
  
//aslan sesi
aslanSound=loadSound("https://file.garden/aCTjXiikymDr1qHZ/Hayvan%20Sesleri%20-%20Aslan%20Sesi%20%F0%9F%A6%81%20(Haaarrrr%C4%B1%C4%B1).mp3")
  
  //adım adım aslan
  aslan[0]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/aslan1-Photoroom.png");
  aslan[1]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/aslan2-Photoroom.png");
  aslan[2]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/aslan3-Photoroom.png");
  aslan[3]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/aslan4-Photoroom.png");
  aslan[4]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/aslan5-Photoroom.png");
  aslan[5]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/aslan6-Photoroom.png");
  aslan[6]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/aslan7-Photoroom.png");
  aslan[7]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/aslan8-Photoroom.png");
}