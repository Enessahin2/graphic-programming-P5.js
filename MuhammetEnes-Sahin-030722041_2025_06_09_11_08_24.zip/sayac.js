class sayacCls{
  
 sayacFnk(){
   
// Sayaç çizimi (oyun duraklasa bile görünür kalır)
fill(255); // Beyaz renk
textSize(24);
textAlign(RIGHT, TOP); // Sağa yaslı, üste hizalı
text("Süre: " + saniyeSayaci + " sn", width - 20, 20); // Sağ üst köşe

// Eğer oyun duraklatıldıysa bir "DURDU" metni göster (isteğe bağlı)
if (oyunDurdu) {
fill("255, 0, 0"); // Kırmızı renk
textSize(48);
textAlign(CENTER, CENTER);
text("DURDU", width / 2, height / 2);
}
   
   
   
} 
  
  
  
sayacGunc(){
// ---SAYAÇ GÜNCELLEME ---
let gecenSaniye = floor((millis() - baslangicSaniyesi) / 1000);
if (gecenSaniye !== saniyeSayaci) {
saniyeSayaci = gecenSaniye;
}
}
}