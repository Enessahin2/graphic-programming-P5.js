let masaUstu;//masaUstuCls sınıfı için 
let bilgisayarKontrol=false;//ekran açık olup olmama durumuna göre window duvar kağıdı
let mouseKontrol=false;//ekran açık olup olmama durumuna göre mouse
let currentScren="window";//yapay bilgisayarın ekranına gelicek sayfayı seçmek için
let klasorEkranı;// klasör ekranını belirten değişken
let dartEkranı;//dart ekranını belirtmek için
let dartItem;//dart sınıfını çağırmak için
let lambaKontrol=true;//lamba açma kapama için
let sesler=[];//ses dosyaları için 
let currentSong=null;//şarkının biri açıkken diğerine geçebilmek için
let button=false;
let mousePressedItem;//mouse pressed için
let windowResimler=[];
let windowButonKontrol=false;
let sutunBool=false;//ana ekranda window ikonuna basınca açılcak sütunu kontrol
let startX, startY;//mouse ile basılı tutup çekildiğinde kutu oluşturmak için
let halkaKontrol=false;//dart ekranında halka kontrol için
let ellipseX=490,ellipseY=100;
let currentEkran;//sayfalar arası geçiş için
let anaSayfa,dartPage;
let dartFırlatıldımı=false;
let savasOyunItem;
let savasOyunEkranı;
let savasEkranıResimler=[];
let x,y,seviye=1,i;
let hp=100,sayac=0;
let dusmanFuzeX = [];
let dusmanFuzeY = [];
let benimHP = 100;
let a=7000,b=2000;
let myHpEkranı;
let sesKontrol=true;
let escKontrol=true;
let keyPressedItem;

//savaş oyunu Değişkenler ve başlangıç değerleri
let aracX = 50, aracY = 700; // Oyuncu aracının başlangıç konumu
let füzeX = [], füzeY = []; // Oyuncu füzelerinin koordinat dizileri
let dusmanAracX; // Düşman aracının X koordinatı
let dusmanAracY = 150; // Düşman aracının sabit Y koordinatı
let pixelGlow = 255; // Piksel parlama efekti için başlangıç değeri
let pixelGlowYukari = false; // Piksel parlama yönü
let rgbTime = 0; // RGB animasyonu için zaman değişkeni
let dusmanFuzeVX = [], dusmanFuzeVY = []; // Düşman füzelerinin hız bileşenleri


//masa üstü sınıfı için
// Görselleri tutacak dizi
let images = [];
// Mouse koordinatları
let moseX = 600, moseY = 650;
// Beyaz noktanın konumu
let noktaX, noktaY;



function preload() {
images[0] = loadImage("/img/monitor/monitor.png");     // Monitör resmi
images[1] = loadImage("/img/monitor/klavye.png");      // Klavye resmi
images[2] = loadImage("/img/monitor/monitorPP.jpg");   // Monitör duvar kağıdı
images[3] = loadImage("/img/monitor/mouse.png");       // Mouse resmi
images[4] = loadImage("/img/monitor/kasa.png");        // Kasa
images[5] = loadImage("/img/monitor/kasaTusu.png");        // Kasa tuşu
images[6] = loadImage("/img/monitor/masa.jpg");        // masa
images[7] = loadImage("/img/monitor/arkaDuvar.jpg");        // arka duvar
images[8] = loadImage("/img/monitor/klasör.png");        // klasör
images[9] = loadImage("/img/monitor/kolResmi.png");        // kol
images[10] = loadImage("/img/monitor/lambaAnahtar.jpg");        // lamba anahtarı
images[11] = loadImage("/img/monitor/kapalıAmpul.png");        // lamba anahtarı
images[12] = loadImage("/img/monitor/acıkAmpul.png");        // lamba apülü
images[13] = loadImage("/img/monitor/halat.png");        // halatı
images[14] = loadImage("/img/monitor/mousePad.png");        // mouse pad
images[15] = loadImage("/img/monitor/kapat.png");        // kapatma tuşu
images[16] = loadImage("/img/monitor/poster.png");        // poster
images[17] = loadImage("/img/monitor/dart.png");        // dart
images[18] = loadImage("/img/monitor/dartOku.png");        // dart oku
images[19] = loadImage("/img/monitor/dartOku2.png");        // dart oku2
images[20] = loadImage("/img/monitor/savasOyunupp.jpg");   // savas oyunu pp
imagesKlasor[0] = loadImage("/img/klasorIci/klasorıcResmı.png"); // Monitör resmi
imagesKlasor[1] = loadImage("/img/klasorIci/geriTusu.png"); //geri tusu için
imagesKlasor[2] = loadImage("/img/klasorIci/musicPP.png"); //müzik pp
sesler[0]=loadSound("https://file.garden/aCTjXiikymDr1qHZ/ROSE%CC%81%20%26%20Bruno%20Mars%20-%20APT.%20(Official%20Music%20Video).mp3");
sesler[1]=loadSound("https://file.garden/aCTjXiikymDr1qHZ/Benson%20Boone%20-%20Beautiful%20Things%20(Official%20Music%20Video).mp3");
sesler[2]=loadSound("https://file.garden/aCTjXiikymDr1qHZ/Ciara%20-%20Level%20Up.mp3");
sesler[3]=loadSound("https://file.garden/aCTjXiikymDr1qHZ/Alex%20Warren%20-%20Ordinary%20(Official%20Music%20Video).mp3");
sesler[4]=loadSound("https://file.garden/aCTjXiikymDr1qHZ/Imran%20Khan%20-%20Satisfya%20(Official%20Music%20Video).mp3");
sesler[5]=loadSound("https://file.garden/aCTjXiikymDr1qHZ/mix_49s%20(audio-joiner.com).mp3");
sesler[6]=loadSound("https://file.garden/aCTjXiikymDr1qHZ/8-bit%20game%20gunshot%20sound(_jnnxqg8TWLc_)%20(mp3cut.net).mp3");
sesler[7]=loadSound("https://file.garden/aCTjXiikymDr1qHZ/sonic-boom-sound-effect-240487%20(mp3cut.net).mp3");
sesler[8]=loadSound("https://file.garden/aCTjXiikymDr1qHZ/Minecraft%20%C3%96l%C3%BCm%20Sesi(_x9uyEVKMzVM_)%20(mp3cut.net).mp3");
windowResimler[0]=loadImage("/img/windowbutonu/windowResmi.png");  //window butonu resmi  
savasEkranıResimler[0]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/67ea91e2ec7a7%20(1).png");  //savaş ekranı  
savasEkranıResimler[1]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/ara%C3%A71.png");  //savaş aracı
savasEkranıResimler[2]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/f%C3%BCze.png");  //füze
savasEkranıResimler[3]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/dusmanArac.png");  //düşman araç
savasEkranıResimler[4]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/fuzeTers.png");  //ters füze
savasEkranıResimler[5]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/anaSayfaGecis-Photoroom.png");  //home işareti 
savasEkranıResimler[6]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/yenidenBasla-Photoroom.png");//tekrarlama işareti
savasEkranıResimler[7]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/hadn-Photoroom.png");//el işareti 
pixelFont = loadFont("PressStart2P-Regular.ttf"); 
savasEkranıResimler[8]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/sesAc%C4%B1k.png");//ses açık
savasEkranıResimler[9]=loadImage("https://file.garden/aCTjXiikymDr1qHZ/sesKapal%C4%B1.jpg");//ses kapalı 
kalpResmi=loadImage("https://file.garden/aCTjXiikymDr1qHZ/kalpResmi-Photoroom.png");
}