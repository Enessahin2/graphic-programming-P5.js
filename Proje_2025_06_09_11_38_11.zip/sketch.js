function setup() {
  createCanvas(800, 800); // Tuval boyutunu ayarla
  masaUstu = new masaUstuCls(); // Masaüstü sınıfı örneği
  klasor = new klasorIciCls();  // Klasör içeriği sınıfı örneği
  windowEkranı = new windowEkranıCls(); // Pencere ekranı sınıfı
  currentSong = sesler[0]; // Mevcut şarkıyı ayarla
  mousePressedItem = new mousePressedCls(); // Mouse tıklama sınıfı
  dartItem = new dartCls(); // Dart ekranı sınıfı
  currentEkran = "anaSayfa"; // Başlangıç ekranı
  savasOyunItem = new savasOyunCls(); // Savaş oyunu sınıfı örneği
  dusmanAracX = random(width); // İlk düşman x pozisyonu rastgele
  keyPressedItem=new keyPressedCls();
  
  
  // Belirli aralıklarla düşman pozisyonunu değiştir
  setInterval(() => {
    dusmanAracX = random(width);
  }, a);

  // Belirli aralıklarla düşman füzesi oluştur
  setInterval(() => {
    dusmanFuzeX.push(dusmanAracX + 30); // x pozisyonu düşmanın ortası
    dusmanFuzeY.push(160);              // y pozisyonu sabit, yukarıdan başlar
  }, b);
}

function draw() {
  background("white"); // Beyaz arka plan

  anaEkranCagırma(); // Ana ekranı çağır
  masaUstu.ekranKarartma(); // Arka planı karartmak için
  ekranSecme(); // Hangi ekranın görüneceğini belirle

  // Arayüz elemanları çizimi
  masaUstu.durdurButtonu(); 
  klasor.musicIsim(); // Müzik üzerine gelince isim göster
  masaUstu.sutunOlusturma(); // Masaüstü sütunlarını oluştur
  masaUstu.windowButonu(); // Windows simgesi
  masaUstu.sutunKlasor(); // Klasör ikonları
  masaUstu.maviKutu(); // Mavi kutu çizimi (seçim)
  masaUstu.beyazNokta(); // Mouse'un ucu
  masaUstu.kolGorseli(); // Kol çizimi

  dartItem.yuvarlak(); // Dart ekranında daire çizimi

  savasOyunItem.fuzeAtıs(); // Oyuncu füzesi gönderme
  savasOyunItem.fuzeGelen(); // Düşman füzesi güncelleme
}

// Ekran seçimi yap
function ekranSecme() {
  if (currentScren == "window") {
    windowEkranı.imgOlusturmaWindow(); // Windows ekranını çiz
  } else if (currentScren == "klasorEkranı") {
    klasor.imgOlusturmaKlasor(); // Klasör ekranını çiz
  }
}

// Ana ekran geçiş ve çağırma
function anaEkranCagırma() {
  if (currentEkran == "anaSayfa") {
    masaUstu.mouseKonum(); // Mouse koordinat kontrolü
    masaUstu.imgOlusturma(); // Masaüstü arayüzü
    masaUstu.kabloEkleme(); // Kablo görselleri
  } else if (currentScren == "dartEkranı") {
    dartItem.imgOlusturmaDart(); // Dart ekranını çiz
  } else if (currentEkran == "savasOyunEkranı") {
    savasOyunItem.imgOlusturmasavasOyun(); // Savaş oyunu çizimi
    savasOyunItem.haraket(); // Oyuncu hareketi
    savasOyunItem.fuzeAtıs(); // Füze gönderme
    savasOyunItem.fuzeGelen(); // Füze takibi
    savasOyunItem.seviyeKontrol(); // Seviye kontrolü
  } else if (currentEkran == "araSayfa") {
    savasOyunItem.imgOlusturmaAra(); // Ara ekranı çiz
  } else if (currentEkran == "myHpEkranı") {
    savasOyunItem.imgOlusturmaHp(); // Can bitti ekranı
  } else if (currentEkran == "girisSayfa") {
    savasOyunItem.imgOlusturmaGiris(); // Giriş ekranı
  }
}


function keyPressed() {
  keyPressedItem.keyPressedFun();
  
}

// Mouse tıklaması
function mousePressed() {
  mousePressedItem.mousePressedFonk(); // Tıklama işlemleri
}

// Mouse bırakıldığında
function mouseReleased() {
  if (halkaKontrol) {
    dartFırlatıldımı = true; // Dart fırlatıldı mı kontrolü
  }
}



function mousePressed(){
mousePressedItem.mousePressedFonk();
}



function mouseReleased(){
if(halkaKontrol){
dartFırlatıldımı=true;  
}
}





