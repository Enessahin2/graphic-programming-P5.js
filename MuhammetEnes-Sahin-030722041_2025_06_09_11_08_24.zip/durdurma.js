class durdurmaCls {
durdurmaFnk() {
oyunDurdu = !oyunDurdu; // Oyun durumunu tersine çevir
if (oyunDurdu) {
     

// 1. Arka plan sesini duraklat 
if (arkaPlanSes && arkaPlanSes.isPlaying()) {
arkaPlanSes.pause();
}
// 2. Kartal sesini hemen durdur
if (kartalsound && kartalsound.isPlaying()) {
kartalsound.stop();
}
// 3. At sesini hemen durdur
if (atsound && atsound.isPlaying()) {
atsound.stop();
}
// 4. Aslan sesini hemen durdur 
if (aslanSound && aslanSound.isPlaying()) {
aslanSound.stop();
}

} else {
     

// 1. Arka plan sesini devam ettir (bu zaten vardı)
if (arkaPlanSes && arkaPlanSes.isPaused()) {
arkaPlanSes.loop(); // loop() fonksiyonu, ses çalmıyorsa play() çağırır
}
}
}
}