class masaUstuCls {

  // Masaüstü görünümünü oluşturan görseller
  imgOlusturma() {
    image(images[7], 400, 0, 800, 1000);             // Arka duvar
    image(images[6], 400, 930, 1300, 1000);          // Masa

    imageMode(CENTER);
    image(images[16], 280, 100, 150, 170);           // Poster
    image(images[17], 490, 100, 180, 180);           // Dart
    image(images[18], 740, 460, 80, 55);             // Dart oku

    image(images[0], width / 2 - 50, height / 2 - 50, 300, 300); // Monitör
    image(images[14], 350, 600, 600, 450);           // Mouse Pad
    image(images[1], 350, 600, 300, 100);            // Klavye
    image(images[3], moseX, moseY, 50, 50);          // Mouse
    image(images[4], 100, 365, 150, 300);            // Kasa
    image(images[5], 121, 362, 30, 30);              // Kasa tuşu
    image(images[10], 700, 300, 80, 80);             // Lamba anahtarı

    // Lamba durumu
    if (lambaKontrol) {
      image(images[12], 700, 150, 60, 60);           // Açık ampul
    } else {
      image(images[11], 700, 150, 35, 55);           // Kapalı ampul
    }

    image(images[13], 695, 50, 100, 150);            // Halat
  }

  // Mouse ve klavye kabloları
  kabloEkleme() {
    fill("black");
    line(width / 2 + 40, height / 2 + 71, moseX, moseY - 25);   // Mouse kablosu
    line(width / 2 - 40, height / 2 + 101, 360, 561);           // Klavye kablosu
  }

  // Mouse ve beyaz noktanın konumlarını hesapla
  mouseKonum() {
    if (mouseX > 550 && mouseX < 770 && mouseY > 530 && mouseY < 700) {
      moseX = constrain(mouseX, 550, 770);
      moseY = constrain(mouseY, 530, 700);
    }

    // Beyaz nokta konumu
    noktaX = constrain(moseX - 315, moseX - 317, 450);
    noktaY = constrain(moseY - 293, moseY - 295, 760);
  }

  // Monitördeki fare beyaz nokta
  beyazNokta() {
    if (
      mouseKontrol &&
      currentEkran == "anaSayfa" &&
      (currentScren == "window" || currentScren == "klasorEkranı")
    ) {
      fill("white");
      rect(noktaX, noktaY, 10);
    }
  }

  // Kol görseli
  kolGorseli() {
    if (
      currentEkran != "savasOyunEkranı" &&
      currentEkran != "araSayfa" &&
      currentEkran != "myHpEkranı" &&
      currentEkran != "girisSayfa"
    ) {
      if (mouseX > 550 && mouseX < 770 && mouseY > 530 && mouseY < 700) {
        image(images[9], moseX, moseY + 100, 180, 270);
      } else {
        image(images[9], mouseX, mouseY + 100, 180, 270);
      }
      imageMode(CENTER);
    }
  }

  // Lamba kapalıysa ekranı karart
  ekranKarartma() {
    if (!lambaKontrol) {
      fill(0, 150);
      rect(0, 0, width, height);
    }
  }

  // Müzik oynatma/durdurma butonu
  durdurButtonu() {
    const ortakKosul = bilgisayarKontrol && currentEkran == "anaSayfa";

    if (ortakKosul && !currentSong?.isPlaying()) {
      fill("grey");
      rect(320, 380, 50, 10);
      fill("white");
      textSize(9);
      text("▶️ Oynat", 322, 388);
      button = false;
    } else if (ortakKosul && currentSong?.isPlaying()) {
      fill("grey");
      rect(320, 380, 50, 10);
      fill("white");
      textSize(10);
      text("⏹ Durdur", 322, 390);
      button = true;
    }
  }

  // Window tuşu (sol alt ikon)
  windowButonu() {
    if (
      bilgisayarKontrol &&
      currentEkran == "anaSayfa" &&
      (currentScren == "window" || currentScren == "klasorEkranı")
    ) {
      image(windowResimler[0], 242, 408, 15, 15);
    }
  }

  // Window menüsünden açılan dikdörtgen kutu (sütun)
  sutunOlusturma() {
    if (sutunBool && bilgisayarKontrol) {
      fill("grey");
      rect(235, 337, 50, 80);
    }
  }

  // Window menüsünde klasör ve savaş oyunu ikonu
  sutunKlasor() {
    if (sutunBool && bilgisayarKontrol) {
      image(images[8], 245, 350, 15, 15);       // Müzik klasörü
      image(images[15], 273, 408, 20, 15);      // Kapat tuşu
      image(images[20], 245, 370, 15, 15);      // Savaş oyunu ikonu
      imageMode(CENTER);
    }
  }

  // Mouse ile mavi kutu çizimi (seçim kutusu)
  maviKutu() {
    push();
    if (
      currentScren != "dartEkranı" &&
      mouseKontrol &&
      currentEkran != "savasOyunEkranı" &&
      currentEkran != "araSayfa" &&
      (currentScren == "window" || currentScren == "klasorEkranı")
    ) {
      noFill();
      stroke(200);
      rect(235, 235, 230, 180);

      if (mouseIsPressed && bilgisayarKontrol) {
        if (
          noktaX >= 235 &&
          noktaX <= 465 &&
          noktaY >= 235 &&
          noktaY <= 415
        ) {
          if (startX === undefined) {
            startX = noktaX;
            startY = noktaY;
          }

          let x1 = constrain(startX, 235, 578);
          let y1 = constrain(startY, 235, 506);
          let x2 = constrain(noktaX, 235, 578);
          let y2 = constrain(noktaY, 235, 506);

          stroke(0, 100, 255);
          strokeWeight(2);

          // Seçim kutusunun 4 kenarı
          line(x1, y1, x2, y1);
          line(x2, y1, x2, y2);
          line(x2, y2, x1, y2);
          line(x1, y2, x1, y1);
        }
      } else {
        startX = undefined;
        startY = undefined;
      }
    }
    pop();
  }
}