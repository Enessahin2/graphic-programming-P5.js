class arkaPlanSnf {
    
arkaPlan() {
// Arka planı çiz
image(arkaPlanFoto[0], arkaPlanX, arkaPlanY, 1500, 600);
image(arkaPlanFoto[1], arkaPlanX + 1500, arkaPlanY, 1500, 600);
arkaPlanX -= 7; 

//arka planda 2 resim var biri diğerinin simetriği bunlar arasında akıcı bir şekilde geçişi yapmak için       
if (arkaPlanX <= -1500) {          
let temp = arkaPlanFoto[0]; 
arkaPlanFoto[0] = arkaPlanFoto[1]; 
arkaPlanFoto[1] = temp; 
arkaPlanX = 0;
}

}
}