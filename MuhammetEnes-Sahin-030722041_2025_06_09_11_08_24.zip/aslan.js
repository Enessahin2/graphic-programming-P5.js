class aslanCls{
// Bu metot, her yeni 'aslanCls' nesnesi oluşturulduğunda çalışır.
// aslanın başlangıç konumunu, animasyon durumunu ve rastgele koşma hızını ayarlar. 
constructor(x, y, gorselDizisi, ses, animasyonHizi) {
this.x = x;
this.y = y;
this.gorselDizisi = gorselDizisi;
this.ses = ses;
this.animasyonHizi = animasyonHizi;
this.genislik = 200;
this.yukseklik = 150;
this.anlikAnimasyonKare = 0;
this.animasyonKareDegisimSayaci = 0;
this.animasyonBasladi = false;
this.removed = false; // BU ÖNEMLİ: statiklik için sadece bikere çağırmak için
this.kosmaHizi = -random(2, 4); // Aslanın kendi bağımsız hareket hızı
}

  
  
aslanFnk(){
// Animasyon karelerini sürekli ilerlet
this.animasyonKareDegisimSayaci++;
if (this.animasyonKareDegisimSayaci >= this.animasyonHizi) {
this.anlikAnimasyonKare++;
this.animasyonKareDegisimSayaci = 0;
if (this.anlikAnimasyonKare >= this.gorselDizisi.length) {
this.anlikAnimasyonKare = 0; // Animasyonu döngüye al
}
}

// X konumunu hareket ettir
this.x += this.kosmaHizi;

// ASLAN EKRAANDAN ÇIKTIĞINDA KENDİNİ KALDIRILMAYA İŞARETLE Tekrar gelmemesi için
if (this.x < -this.genislik) {
this.removed = true; // Bu aslanı diziden kaldırmak için işaretle
this.animasyonBasladi = false; // Ses durumunu sıfırla 
this.anlikAnimasyonKare = 0; // Animasyon karesini sıfırla
this.animasyonKareDegisimSayaci = 0; // Animasyon sayacını sıfırla
}

// Ses çalma mantığı 
if (this.x < width && this.x > -this.genislik && !this.animasyonBasladi && !this.removed) {
if (this.ses && this.ses.isLoaded()) {
this.ses.play();
}
this.animasyonBasladi = true;
}

// Aslanı çiz (sadece kaldırılmadıysa çiz)
if (this.gorselDizisi[this.anlikAnimasyonKare] && !this.removed) {
image(this.gorselDizisi[this.anlikAnimasyonKare], this.x, this.y, this.genislik, this.yukseklik);
}
}

  
aslanSetup(){
    
// --- ASLAN NESNELERİNİ OLUŞTURMA ---
// Aslanları bağımsız hareket edecek şekilde başlatıyoruz.
// X konumu,  ekran üzerindeki başlangıç X'i olacak.
aslanNesneleri.push(new aslanCls(width + random(100, 200), height * 0.75, aslan, aslanSound, 4));
aslanNesneleri.push(new aslanCls(width + random(500, 700), height * 0.75, aslan, aslanSound, 4));

}

  
aslanDrw(){
// --- ASLAN NESNELERİNİ GÜNCELLE VE ÇİZ ---
// Aslanlar bağımsız hareket edip döngüye girecekler.
for (let i = 0; i < aslanNesneleri.length; i++) {
aslanNesneleri[i].aslanFnk();
}
}
}