class atSnf {
// Bu yapıcı metot, her yeni 'atSnf' nesnesi oluşturulduğunda çalışır.
// Atın başlangıç konumunu, animasyon durumunu ve rastgele koşma hızını ayarlar. 
constructor(x, y) {
this.x = x;// Atın ekran üzerindeki X konumu
this.y = y;// Atın ekran üzerindeki Y konumu
this.AnlıkAtKare = 0;// At animasyonunun şu anki karesinin indeksi
this.AtKareDegisim = 0;// At animasyon karesi değişimini kontrol eden sayaç
this.kosmaHizi = -random(0.2, 0.4); // yavaş sola hareket
}

atFonk() {

// Animasyon karesi geçişi
this.AtKareDegisim++;
if (this.AtKareDegisim >= atKanarHızı) {
this.AnlıkAtKare++;
this.AtKareDegisim = 0;
if (this.AnlıkAtKare >= at.length) {
this.AnlıkAtKare = 0;
}
}

  
// Yavaş sola doğru ilerleme
this.x += this.kosmaHizi;

  
// Ekranın solundan çıkarsa sağdan tekrar başla
if (this.x < -150) {
this.x = width + random(100, 300); // sağdan span
this.y = random(height * 0.6, height * 0.75); // rastgele y
}

  
// Atı çiz
if (at[this.AnlıkAtKare]) {
image(at[this.AnlıkAtKare], this.x, this.y, 150, 100);
}
}
  
  
  
atSetupFonk(){
    

//at genişliği
const atVarsayilanGenislik = 150;

// Atlar arasındaki minimum mesafe 
const atMinimumMesafe = atVarsayilanGenislik * 1.5;

// Bu döngü, başlangıçta 3 at oluşturacak ve bunları atNesneleri dizisine ekleyecek.
for (let i = 0; i < 3; i++) {

  
// Atların başlangıç X konumunu ayarla
// Her atı birbirinden belirli bir mesafe kadar uzaklaştır
// atın rasgele konumda oluşmasını sağlar
let baslangicX = i * atMinimumMesafe + random(0, width - (3 * atMinimumMesafe));
let baslangicY = random(height * 0.6, height * 0.75); // farklı Y konumu
atNesneleri.push(new atSnf(baslangicX, baslangicY));
}
}
} 