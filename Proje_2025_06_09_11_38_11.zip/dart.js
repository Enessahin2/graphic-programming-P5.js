let okX=245,okY=390;
class dartCls{
  
  
imgOlusturmaDart(){
    
    
    image(images[7], 400, 0, 800, 1500);                         // arka duvar
    
    image(images[17], 490, 100, 180, 180);                         //dart
    imageMode(CENTER);
    
    image(images[16], 280, 100, 150, 170);                         //poster
    imageMode(CENTER);
  
    image(images[10], 700, 300, 80, 80);                         // lamba anahtarı
    imageMode(CENTER);
    
    if(lambaKontrol){
      image(images[12], 700, 150, 60, 60);                         // lamba ampülü
    imageMode(CENTER); 
    }
    else if(!lambaKontrol){
    image(images[11], 700, 150, 35, 55);                         // lamba ampülü
    imageMode(CENTER);
    }
    image(images[13], 695, 50, 100, 150);                         // halat
    imageMode(CENTER);
  
  
//dart oyunundaki dart2 görselinin konumunu belirlemek için if ile çağırımı
if(mouseX >155&&mouseX < 330 && mouseY >300 && mouseY < 480&& !dartFırlatıldımı){
image(images[19],  mouseX, mouseY, 100, 100);                         //dart oku2
imageMode(CENTER);
}
else if(halkaKontrol&&dartFırlatıldımı){
okX-=0.00001;
okY-=0.00001;
okX=max(ellipseX-45,-1);
okY=max(ellipseY+38,-1);
image(images[19],  okX, okY, 100, 100);                      //dart oku2
imageMode(CENTER);    
}
else{
image(images[19],  245, 390, 100, 100);                         //dart oku2
imageMode(CENTER);
}


  
// Yazı  
push(); 
fill(0, 150);
rect(width / 2 - 300, height - 120, 600, 40, 10);
fill(255);
textAlign(CENTER, CENTER);
textSize(20);
text("Bilgisayar ekranına dönmek için B tuşuna basınız", width / 2, height - 100);
pop();
  
//dartı sınırladığımız kırmızı alan  
push();
stroke("red");
line(155,300,330,300);
line(155,300,155,480);
line(155,480,330,480);
line(330,480,330,300);
pop();
}
    
// hedef alma yuvarlağını oluşturma
yuvarlak(){
if(mouseIsPressed&& currentScren=="dartEkranı"&&mouseX >155&&mouseX < 330 && mouseY >300 && mouseY < 480 && halkaKontrol){
push();  
halkaKontrol=true;
noFill();
stroke("red");
strokeWeight(4); 
ellipseX = constrain(mouseX + 255, mouseX + 255, 700);
ellipseY = constrain(mouseY - 295, mouseY - 295, 760);
ellipse(ellipseX, ellipseY, 20, 20);
pop();
}
}
  
  
  
  
  
}