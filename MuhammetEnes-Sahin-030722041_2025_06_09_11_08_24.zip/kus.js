class kusCls{
// Bu yapıcı metot, her yeni 'kusCls' nesnesi oluşturulduğunda çalışır.
// kuşun başlangıç konumunu, animasyon durumunu ve rastgele uçma hızını ayarlar.
constructor(x, y) {
this.x = x; // Kuşun ekran üzerindeki X konumu
this.y = y; // Kuşun ekran üzerindeki Y konumu
this.AnlıkKusKare = 0; // Kuş animasyonunun şu anki karesinin indeksi
this.KusKareDegisim = 0; // Kuş animasyon karesi değişimini kontrol eden sayaç
this.ucmaHizi = -random(0.5, 1.5); // Kuşun yatay hareket hızı. Negatif değer sola doğru hareketi sağlar.
this.genislik = 80; // Kuşun genişliği (görselin boyutuna göre ayarlayabilirsiniz)
this.yukseklik = 60; // Kuşun yüksekliği
this.animasyonHizi = 4; // Kuşun kanat çırpma hızı (düşük değer = daha hızlı animasyon)
}


kusFnk(){
// Animasyon karesi geçişi
this.KusKareDegisim++;
if (this.KusKareDegisim >= this.animasyonHizi) {
this.AnlıkKusKare++;
this.KusKareDegisim = 0;
if (this.AnlıkKusKare >= kus.length) {
this.AnlıkKusKare = 0;
}
}

// Sola doğru ilerleme
this.x += this.ucmaHizi;

// Ekranın solundan çıkarsa sağdan tekrar başla
if (this.x < -this.genislik) {
this.x = width + random(50, 200); // Sağdan, ekranın dışında bir yerden spawn
// Kuşun Y konumu: At ile Kartal arasında çünkü kuş kartal kadar yükselemez
this.y = random(height * 0.2, height * 0.45); // Daha yüksek, ama kartal kadar değil
}

// Kuşu çiz
if (kus[this.AnlıkKusKare]) {
image(kus[this.AnlıkKusKare], this.x, this.y, this.genislik, this.yukseklik);
}
}

  
//kuş için set up da olması gereken tanımlamalar vs 
kusSetupfnk(){
    
//  üst üste binmemeleri için mesafe ayarı yapalım.
const kusVarsayilanGenislik = 80; // kusCls'deki genişlik ile uyumlu olmalı
const kusMinimumMesafe = kusVarsayilanGenislik * 2; // Aralarında daha fazla boşluk bırak

// Başlangıçta 3 kuş oluştur ve kusNesneleri dizisine ekle
for (let i = 0; i < 3; i++) { // Başlangıçta 3 kuş oluşturma
let baslangicX = i * kusMinimumMesafe + random(0, width - (3 * kusMinimumMesafe));
let baslangicY = random(height * 0.2, height * 0.45); // Kuşun uçuş yüksekliği aralığı
kusNesneleri.push(new kusCls(baslangicX, baslangicY));
}
}
  
  
  
}