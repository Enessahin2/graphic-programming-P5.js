class kartalCls {
// kartla dair herşeyin kontrolü
kartalFonk() {

  
// ekran yenileme hızına göre animasyon karelerinin değişim sıklığını belirler.
KartalKareDegisim++;

  
  
// Eğer 'KartalKareDegisim' sayacı, 'kartalKanarHızı' değerine ulaşmışsa 
if (KartalKareDegisim >= kartalKanarHızı) {
AnlıkKartalKare++;
KartalKareDegisim = 0;

  
  
// Eğer 'AnlıkKartalKare' kartal görselleri dizisinin sonuna  ulaşmışsa:
if (AnlıkKartalKare >= kartal.length) {
AnlıkKartalKare = 0; // İndeksi 0'a sıfırlar. Bu, kanat çırpma animasyonunun sonsuz bir döngüde devam etmesini sağlar.
}
}

// --- Kartalın Yatayda İlerlemesi ---
// Bu, kartalın ekran boyunca soldan sağa doğru ilerlemesini sağlar.
kartalX += kartalUcmaHızı;

  
// --- Kartalın Ekrandan Çıkıp Tekrar Belirmesi ve Rastgele Y Konumu ---
if (kartal[AnlıkKartalKare]) {
// Eğer kartalın sol kenarı ekranın sağ kenarını geçmişse 
if (kartalX > width) {
kartalX = -kartal[AnlıkKartalKare].width;

// --- Kartalın Y Konumunu Rastgele Değiştirme ---
// Kartalın ekrana gelebileceği minimum dikey konumu 
let minY = 50;
// Kartalın ekrana gelebileceği maksimum dikey konumu
let maxY = height / 2; 


//  kartal her ekrana döndüğünde farklı bir yükseklikten gelir.
kartalY = random(minY, maxY);
}
}

// --- Kartalın Ekrana Çizilmesi ---
if (kartal[AnlıkKartalKare]) {
image(kartal[AnlıkKartalKare], kartalX, kartalY,70,40);
}
}
}