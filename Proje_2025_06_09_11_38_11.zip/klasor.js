let imagesKlasor=[];
class klasorIciCls {

// klasör içi görünümünü oluşturan görseller
imgOlusturmaKlasor() {
if(bilgisayarKontrol && currentScren=="klasorEkranı"){//eğer bilgisayar açıksa
image(imagesKlasor[0], 348, 326, 230, 180); // klasor ici görünümü
imageMode(CENTER);
  
image(imagesKlasor[1],266, 266, 60, 60); // geri tuşu
imageMode(CENTER);
      
image(imagesKlasor[2],330, 266, 60, 60); // müzik için duvar kağıdı
imageMode(CENTER);
      
image(imagesKlasor[2],410, 266, 60, 60); // müzik için duvar kağıdı
imageMode(CENTER);

image(imagesKlasor[2],330, 330, 60, 60); // müzik için duvar kağıdı
imageMode(CENTER);
      
image(imagesKlasor[2],410, 330, 60, 60); // müzik için duvar kağıdı
imageMode(CENTER); 
  
image(imagesKlasor[2],266, 330, 60, 60); // müzik için duvar kağıdı
imageMode(CENTER); 
}
}
  
//müzik için isim yazdırma
 musicIsim(){
if(noktaX>300 && noktaX<366 && noktaY>236 && noktaY<296 && currentScren=="klasorEkranı" && bilgisayarKontrol){
fill("black");
textSize(12);           // 1.müsik
text("APT", 300, 300);  
}
else if(noktaX>380 && noktaX<440 && noktaY>236 && noktaY<296 && currentScren=="klasorEkranı" && bilgisayarKontrol){
fill("black");
textSize(11);           // 2.müsik
text("Beautiful Things", 380, 300);
}
else if(noktaX>380 && noktaX<440 && noktaY>316 && noktaY<376 && currentScren=="klasorEkranı" && bilgisayarKontrol){
fill("black");
textSize(11);           // 5.müsik
text("Level Up", 380, 376);
}
  
else if(noktaX>300 && noktaX<366 && noktaY>300 && noktaY<360 && currentScren=="klasorEkranı" && bilgisayarKontrol){
fill("black");
textSize(11);           // 4.müsik
text("ordinary", 300, 376);
}  
else if(noktaX>233 && noktaX<332 && noktaY>300 && noktaY<360 && currentScren=="klasorEkranı" && bilgisayarKontrol){
fill("black");
textSize(11);           // 3.müsik
text("Satisfya", 239, 376);
} 
}
}
  

