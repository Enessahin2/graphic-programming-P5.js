class sesCls{

  sesFnk(){
    //arka planda ses oynatmak için
    // Bu sesin duraklatılması/devam ettirilmesi togglePause() fonksiyonu tarafından yönetiliyor.
    arkaPlanSes.setVolume(0.5);
    arkaPlanSes.loop();

    //kartal sesi için
    setInterval(() => {
      if (!oyunDurdu) { // Oyun duraklamadıysa sesi çal
        if (kartalsound.isLoaded()) { // Sesin yüklendiğinden emin ol
          kartalsound.play();
        }
      }
    }, 5000);

    //birden fazla at olduğu için farklı zamanlamalarla at sesleri için
    setInterval(() => {
      if (!oyunDurdu) { // Oyun duraklamadıysa sesi çal
        if (atsound.isLoaded()) { // Sesin yüklendiğinden emin ol
          atsound.setVolume(0.1);
          atsound.play();
        }
      }
    }, 35000);

    setInterval(() => {
      if (!oyunDurdu) { //  Oyun duraklamadıysa sesi çal
        if (atsound.isLoaded()) { // Sesin yüklendiğinden emin ol
          atsound.setVolume(0.1);
          atsound.play();
        }
      }
    }, 30000);

    setInterval(() => {
      if (!oyunDurdu) { // Oyun duraklamadıysa sesi çal
        if (atsound.isLoaded()) { // Sesin yüklendiğinden emin ol
          atsound.setVolume(0.1);
          atsound.play();
        }
      }
    }, 20000);
  }
}