class windowEkranıCls{
  //eğer bilgisayar açıksa ekrana gelicek uygulama resimleri 
  imgOlusturmaWindow(){
    if(bilgisayarKontrol && currentScren=="window"){
  
    image(images[2], 348, 326, 230, 180); // Monitör duvar kağıdı
    imageMode(CENTER);
  
    image(images[8], 266, 266, 60, 60);        // klasör
    imageMode(CENTER);
      
    image(images[20], 326, 266, 40, 40);        // savas oyunu 
    imageMode(CENTER);
  
}
  }
  
   
  
  
}