function setup() {
createCanvas(800, 600);

//sınıf elemanlarını oluşturma ve bağzılarını çağırma
bgItem = new arkaPlanSnf();
kartalItem = new kartalCls();
sesItem=new sesCls();
sesItem.sesFnk();//sesleri oluşturmak için
kusItem=new kusCls();
kusItem.kusSetupfnk();//kuşa ait tanımlamalar
durdurmaItem=new durdurmaCls();
atItem=new atSnf();
atItem.atSetupFonk()//atlar için gerekli set up kodları için
sayacItem=new sayacCls();
aslanItem=new aslanCls();
  
  
//arka arkaya gelen fotoların daha iyi gözükmesi için ekran yenileme hızı düşürmek için
frameRate(30);
  
  
  
// ---  SAYAÇ BAŞLATMA ---
baslangicSaniyesi = millis(); // Sayacı başlat  
  // ########################################################################################
  // #ÖNEMLİ NOT: ASLANLARIN DAVRANIŞI STATİKTİR EKRANA BİR KEZ GELİRLER DÖNGÜ DEĞİLDİR     #
    //#######################################################################################
  aslanItem.aslanSetup();
 
}


function draw() {
background("black");

// --- OYUN DURAKLATILMADIYSA ÇALIŞACAK KODLAR ---
if (!oyunDurdu) { //
// Arka planı haraketi ve görsellerini yükleme
bgItem.arkaPlan();

//kartala dair görüntü ve işlevler
kartalItem.kartalFonk();

// atNesneleri dizisindeki tüm atları güncelleyip çiz
for (let i = 0; i < atNesneleri.length; i++) {
atNesneleri[i].atFonk();
}

// kusNesneleri dizisindeki tüm kuşları güncelleyip çiz
for (let i = 0; i < kusNesneleri.length; i++) {
kusNesneleri[i].kusFnk();
}

sayacItem.sayacGunc();
aslanItem.aslanDrw();
}

//animasyon dursa bile ekrana gelecek durdurma menüsü  
sayacItem.sayacFnk();
 
}





