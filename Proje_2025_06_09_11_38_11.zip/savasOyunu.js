let kalpX = -100;
let kalpY = -100;
let kalpGorunuyorMu = false;
let kalpCikisZamani = 0;
let kalpAktifMi = false;
let kalpBekleme = false;
let kalpCanSeviyesi = null; // 40 mı 20 mi diye hatırlamak için


// Savaş oyunu sınıfı
class savasOyunCls {

  // Savaş ekranındaki görselleri oluşturur ve ekrana çizer
  imgOlusturmasavasOyun() {
    image(savasEkranıResimler[0], 400, 250, 2000,1200 ); // Arka plan
    image(savasEkranıResimler[1], aracX, aracY, 300,150 ); // Oyuncunun aracı
    image(savasEkranıResimler[3], dusmanAracX, dusmanAracY, 150,150 ); // Düşman aracı

    push();
    textFont(pixelFont);
    textSize(22);
    textAlign(LEFT, TOP);

    // Düşman can göstergesi
    let dusmanHpX = 20;
    let dusmanHpY = 20;
    fill(0, 0, 0, 150);
    rect(dusmanHpX - 10, dusmanHpY - 10, 310, 40, 10);
    fill(255, 0, 0);
    image(kalpResmi, dusmanHpX+15, dusmanHpY+10, 30, 30); // Kalp simgesi
    text(" DÜŞMAN: " + hp, dusmanHpX + 30, dusmanHpY);

    // Oyuncu can göstergesi
    let benimHpX = 20;
    let benimHpY = height - 60;
    fill(0, 0, 0, 150);
    rect(benimHpX - 10, benimHpY - 10, 220, 40, 10);
    fill(0, 255, 0);
    image(kalpResmi, benimHpX+15, benimHpY+10, 30, 30); // Kalp simgesi
    text(" BEN: " + benimHP, benimHpX + 30, benimHpY);
    pop();

    // Bilgilendirme metni (ESC ile durdur)
    push(); 
    fill(0, 150);
    rect(width / 2 - 55, 4, 450, 40, 10);
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(20);
    text("Durdurmak İçin ESC Tuşuna Basınız", width / 2+190, 20);
    pop();
  }

  // Oyuncu aracının sola/sağa hareketi
  haraket() {
    if (keyIsPressed) {
      if (key === "d") {
        aracX += 7; // sağa hareket
        if (aracX > 760) { aracX = 760; } // sağ sınır
      }
      if (key === "a") {
        aracX -= 7; // sola hareket
        if (aracX < 30) { aracX = 30; } // sol sınır
      }
    }
  }

  // Düşmanın attığı füzeleri kontrol eder ve çizer
fuzeGelen() {
  if (currentEkran === "savasOyunEkranı" && bilgisayarKontrol) {
    for (let i = 0; i < dusmanFuzeX.length; i++) {
      let hedefX = aracX;
      let mevcutX = dusmanFuzeX[i];

      // Füzenin X koordinatını oyuncuya yaklaştır (takip algoritması)
      let hizCarpani = seviye === 1 ? 0.008 : seviye === 2 ? 0.03 : 0.025;
      dusmanFuzeX[i] += (hedefX - mevcutX) * hizCarpani;

      let posX = dusmanFuzeX[i]; // hesaplama kolaylığı için

      if (seviye === 1) {
        // Seviye 1: tek füze, görsel -20 px ortalanmış
        image(savasEkranıResimler[4], posX - 20, dusmanFuzeY[i], 50, 70);
        dusmanFuzeY[i] += 5;
      } else if (seviye === 2) {
        // Seviye 2: çift füze
        image(savasEkranıResimler[4], posX - 30, dusmanFuzeY[i], 50, 70);
        image(savasEkranıResimler[4], posX - 10, dusmanFuzeY[i], 50, 70);
        dusmanFuzeY[i] += 7;
      } else {
        // Seviye 3+: üçlü füze
        image(savasEkranıResimler[4], posX - 30, dusmanFuzeY[i], 50, 70);
        image(savasEkranıResimler[4], posX - 0, dusmanFuzeY[i], 50, 70);
        image(savasEkranıResimler[4], posX + 30, dusmanFuzeY[i], 50, 70);
        dusmanFuzeY[i] += 7;
      }

      // === Çarpışma kontrolü ===
      let carptiMi = false;

      if (
        (posX - 20 > aracX - 50 && posX - 20 < aracX + 50 &&
         dusmanFuzeY[i] > aracY - 30 && dusmanFuzeY[i] < aracY + 30)
      ) {
        carptiMi = true;
      }

      if (seviye >= 2) {
        if (
          (posX + 10 > aracX - 50 && posX + 10 < aracX + 50 &&
           dusmanFuzeY[i] > aracY - 30 && dusmanFuzeY[i] < aracY + 30)
        ) {
          carptiMi = true;
        }
      }

      if (seviye >= 3) {
        if (
          (posX + 30 > aracX - 50 && posX + 30 < aracX + 50 &&
           dusmanFuzeY[i] > aracY - 30 && dusmanFuzeY[i] < aracY + 30)
        ) {
          carptiMi = true;
        }
      }

      if (carptiMi) {
        benimHP -= (seviye === 1 ? 5 : seviye * 5);
        sesler[8].play(); // vurulma sesi

        // Füze silinir
        dusmanFuzeX.splice(i, 1);
        dusmanFuzeY.splice(i, 1);
        i--;

        // Oyuncu öldü mü?
        if (benimHP <= 0) {
          currentEkran = "myHpEkranı";
          break;
        }
      }
    }
  }
}


  // Oyuncunun attığı füzeleri kontrol eder ve çizer
  fuzeAtıs() {
    if (currentEkran === "savasOyunEkranı" && bilgisayarKontrol) {
      for (let i = 0; i < füzeX.length; i++) {
        image(savasEkranıResimler[2], füzeX[i], füzeY[i], 50, 70);

        if (seviye === 1) {
          füzeY[i] -= 7;
        } else if(seviye==2){
          image(savasEkranıResimler[2], füzeX[i] + 30, füzeY[i], 50, 70);
          füzeY[i] -= 12;
        }
        else {
          image(savasEkranıResimler[2], füzeX[i] + 30, füzeY[i], 50, 70);
          image(savasEkranıResimler[2], füzeX[i] - 30, füzeY[i], 50, 70);
          füzeY[i] -= 12;
        }

        // Füze düşmana çarptı mı?
        if (
          füzeX[i] > dusmanAracX - 60 &&
          füzeX[i] < dusmanAracX + 60 &&
          füzeY[i] > 160 &&
          füzeY[i] < 230
        ) {
          hp -= (seviye === 1 ? 2 : 3); // düşman hasar alır
          
          // Seviye sayısı kadar ses çal
          for (let i = 0; i < seviye; i++) {
            sesler[7].setVolume(0.7);
            sesler[7].play();
          }

          // Füze silinir
          füzeX.splice(i, 1);
          füzeY.splice(i, 1);
          i--;
        }
      }
    }
  }




  // Oyunu baştan başlatır, tüm değerleri sıfırlar
  oyunuSifirla() {
    aracX = 50;
    aracY = 700;
    dusmanAracX = random(100, 700);
    dusmanAracY = 150;

    // Tüm füzeleri sıfırla
    füzeX = [];
    füzeY = [];
    dusmanFuzeX = [];
    dusmanFuzeY = [];

    // Can ve durum değerlerini sıfırla
    benimHP = 100;
    hp = 100;
    sayac = 0;
    seviye = 1;
    currentEkran = "savasOyunEkranı";

    this.oyunAyarlariGuncelle();
  }

  // Seviye arttıkça ateş hızlarını günceller
  oyunAyarlariGuncelle() {
    b = max(400, 1000 - seviye * 200); // oyuncu atış hızı
    a = max(2000, 4000 - seviye * 500); // düşman atış süresi
  }

  // Eğer düşmanın canı biterse seviyeyi yükselt
  seviyeKontrol() {
    if (hp <= 0) {
      seviye++;
      hp = seviye * 100;
      benimHP = 100;
      sayac = 0;
      this.oyunAyarlariGuncelle();
    }
  }

imgOlusturmaAra() {
  push();

  // Ekran durumu "araSayfa" olarak ayarlanır
  currentEkran = "araSayfa";

  // Arka plan ve yarı saydam katman çizilir
  image(savasEkranıResimler[0], 200, 250, 2000, 1200);
  fill(0, 150);
  rect(width / 2 - 500, 4, 2000, 1200, 10); // saydam siyah arkaplan

  // Sol orta buton
  fill(0, 150);
  rect(width / 2 - 70, height / 2, 80, 120, 10);
  push();
  fill("white");
  rect(width / 2 - 62, height / 2 + 10, 62, 100, 10);
  pop();

  // Ses kontrol butonu görseli
  if (sesKontrol) {
    image(savasEkranıResimler[8], 720, 70, 100, 100);
  } else {
    image(savasEkranıResimler[9], 720, 70, 100, 100);
  }

  push();
  textFont(pixelFont);
  textAlign(CENTER, CENTER);
  textSize(20);

  // RGB animasyon renk hesaplamaları
  let r = sin(rgbTime) * 127 + 128;
  let g = sin(rgbTime + TWO_PI / 3) * 127 + 128;
  let b = sin(rgbTime + (2 * TWO_PI) / 3) * 127 + 128;

  // Sinüs dalga efekti
  let dalga = sin(rgbTime * 2) * 10;
  let centerX = width / 2;
  let startY = height / 6 + dalga;
  let lineHeight = 40;

  // Metin kutusu arkaplanı
  let kutuGenislik = 320;
  let kutuYukseklik = 3 * lineHeight + 30;
  fill(0, 180);
  noStroke();
  rectMode(CENTER);
  rect(centerX, startY + lineHeight, kutuGenislik, kutuYukseklik, 10);

  // Animasyonlu RGB yazılar
  fill(r, g, b);
  stroke(0);
  strokeWeight(3);
  text("OYUN", centerX, startY);
  text("ARASI", centerX, startY + lineHeight);
  text("VERELİM", centerX, startY + 2 * lineHeight);
  pop();

  // RGB zaman sayacını ilerlet
  rgbTime += 0.05;
  pop();

  // Üçgen (oynat butonu gibi)
  push();
  noFill();
  triangle(width / 2 - 50, height / 2 + 20, width / 2 - 50, height / 2 + 100, width / 2, height / 2 + 60);
  pop();

  // Sol alt: yeniden başlatma görseli
  push();
  fill(0, 150);
  rect(width / 2, height / 2 + 150, 80, 120, 10);
  rect(width / 2 + 40, height / 2, 80, 120, 10);
  fill("white");
  rect(width / 2 + 10, height / 2 + 160, 60, 100, 10);
  image(savasEkranıResimler[6], width / 2 + 40, height / 2 + 200, 54, 52);
  pop();

  // Sağ buton - devam et görseli
  push();
  fill("white");
  rect(width / 2 + 50, height / 2 + 10, 60, 100, 10);
  image(savasEkranıResimler[5], width / 2 + 80, height / 2 + 50, 80, 150);
  pop();

  // Mouse imleci görseli
  image(savasEkranıResimler[7], mouseX + 5, mouseY + 5, 50, 50);
}

  
  
 imgOlusturmaGiris() {
  push();
  currentEkran = "girisSayfa";

  // Arka plan ve siyah katman
  image(savasEkranıResimler[0], 200, 250, 2000, 1200);
  fill(0, 150);
  rect(width / 2 - 500, 4, 2000, 1200, 10);

  // Girişteki sol buton
  fill(0, 150);
  rect(width / 2 - 70, height / 2, 80, 120, 10);
  push();
  fill("white");
  rect(width / 2 - 62, height / 2 + 10, 62, 100, 10);
  pop();

  // Ses açık/kapalı görseli
  if (sesKontrol) {
    image(savasEkranıResimler[8], 720, 70, 100, 100);
  } else {
    image(savasEkranıResimler[9], 720, 70, 100, 100);
  }

  push();
  textFont(pixelFont);
  textAlign(CENTER, CENTER);
  textSize(20);

  // RGB animasyon hesaplamaları
  let r = sin(rgbTime) * 127 + 128;
  let g = sin(rgbTime + TWO_PI / 3) * 127 + 128;
  let b = sin(rgbTime + (2 * TWO_PI) / 3) * 127 + 128;
  let dalga = sin(rgbTime * 2) * 10;

  // Metin kutusu
  let centerX = width / 2;
  let startY = height / 6 + dalga;
  let lineHeight = 40;
  let kutuGenislik = 320;
  let kutuYukseklik = 3 * lineHeight + 30;

  fill(0, 180);
  noStroke();
  rectMode(CENTER);
  rect(centerX, startY + lineHeight, kutuGenislik, kutuYukseklik, 10);

  // Hoşgeldin metni
  fill(r, g, b);
  stroke(0);
  strokeWeight(3);
  text("HOŞ", centerX, startY);
  text("GELDİN", centerX, startY + lineHeight);
  text("OYUNA", centerX, startY + 2 * lineHeight);
  pop();

  // RGB zaman sayacını arttır
  rgbTime += 0.05;
  pop();

  // Üçgen ikon (başlat tuşu efekti)
  push();
  noFill();
  triangle(width / 2 - 50, height / 2 + 20, width / 2 - 50, height / 2 + 100, width / 2, height / 2 + 60);
  pop();

  // Sağda "oyuna başla" görseli
  push();
  fill(0, 150);
  rect(width / 2 + 40, height / 2, 80, 120, 10);
  fill("white");
  rect(width / 2 + 50, height / 2 + 10, 60, 100, 10);
  image(savasEkranıResimler[5], width / 2 + 80, height / 2 + 50, 80, 150);
  pop();

  // Mouse imleci
  image(savasEkranıResimler[7], mouseX + 5, mouseY + 5, 50, 50);
}

imgOlusturmaHp() {
  push();
  currentEkran = "myHpEkranı";

  // Arka plan ve saydam katman
  image(savasEkranıResimler[0], 200, 250, 2000, 1200);
  fill(0, 150);
  rect(width / 2 - 500, 4, 2000, 1200, 10);

  // Sol buton kutusu
  fill(0, 150);
  rect(width / 2 - 70, height / 2, 80, 120, 10);
  push();
  fill("white");
  rect(width / 2 - 62, height / 2 + 10, 62, 100, 10);
  pop();

  // Ses kontrol simgesi
  if (sesKontrol) {
    image(savasEkranıResimler[8], 720, 70, 100, 100);
  } else {
    image(savasEkranıResimler[9], 720, 70, 100, 100);
  }

  push();
  textFont(pixelFont);
  textAlign(CENTER, CENTER);
  textSize(20);

  // RGB dalgalı metin hesaplaması
  let r = sin(rgbTime) * 127 + 128;
  let g = sin(rgbTime + TWO_PI / 3) * 127 + 128;
  let b = sin(rgbTime + (2 * TWO_PI) / 3) * 127 + 128;
  let dalga = sin(rgbTime * 2) * 10;

  let centerX = width / 2;
  let startY = height / 6 + dalga;
  let lineHeight = 40;
  let kutuGenislik = 320;
  let kutuYukseklik = 3 * lineHeight + 30;

  fill(0, 180);
  noStroke();
  rectMode(CENTER);
  rect(centerX, startY + lineHeight, kutuGenislik, kutuYukseklik, 10);

  // "Canınız bitti" metni
  fill(r, g, b);
  stroke(0);
  strokeWeight(3);
  text("MALESEF", centerX, startY);
  text("CANINIZ", centerX, startY + lineHeight);
  text("BİTTİ", centerX, startY + 2 * lineHeight);
  pop();

  // RGB zaman akışı
  rgbTime += 0.05;
  pop();

  // Tekrar oyna simgesi
  push();
  image(savasEkranıResimler[6], width / 2 - 33, height / 2 + 55, 54, 52);
  pop();

  // Sağ buton kutusu ve devam ikonu
  push();
  fill(0, 150);
  rect(width / 2 + 40, height / 2, 80, 120, 10);
  fill("white");
  rect(width / 2 + 50, height / 2 + 10, 60, 100, 10);
  image(savasEkranıResimler[5], width / 2 + 80, height / 2 + 50, 80, 150);
  pop();

  // Mouse imleci
  image(savasEkranıResimler[7], mouseX + 5, mouseY + 5, 50, 50);
}

}